<?php
include 'config.php';
date_default_timezone_set('Asia/Kolkata');
$hour = date('H');  
$minute = date('i');  

if ($hour == 9 && $minute <= 35) {
    $category = 'day';  
} else if ($hour == 9 && $minute <= 40) {
    $category = 'night';  
} else {
    $category = 'day';  
}

$query = "SELECT image_url FROM slideshow_images WHERE category = '$category'";
$result = $conn->query($query);

$response = [
    'category' => $category,
    'date_time' => date('Y-m-d H:i:s'),  
];


if ($result->num_rows > 0) {
    $images = [];
    while ($row = $result->fetch_assoc()) {
        $images[] = $row; 
    }

    $response['images'] = $images; 

    echo json_encode($response);  
} else {
    $response['images'] = [];  
    echo json_encode($response); 
}

$conn->close();  
?>
