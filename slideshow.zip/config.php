<?php
$conn = mysqli_connect("localhost", "root", "", "slideshow_db");
?>