<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Image Slider</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .carousel-inner img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .info {
            font-size: 18px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

            <div id="slideshow" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                		<!-- Data Dynamically-->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#slideshow" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#slideshow" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

            <div id="info" class="info"></div>

<script>
    fetch('get_images.php')  
        .then(response => response.json())
        .then(data => {
            const carouselInner = document.querySelector('.carousel-inner');
            const infoDiv = document.getElementById('info');

            infoDiv.innerHTML = ` <div class="text-center">
	        		Current Category: <strong>${data.category}</strong><br>
	        		Date and Time: <strong>${data.date_time}</strong>
	    		</div>`;

            data.images.forEach((image, index) => {
                let item = document.createElement('div');
                item.classList.add('carousel-item');
                if (index === 0) item.classList.add('active'); 

                let img = document.createElement('img');
                img.src = image.image_url;
                img.classList.add('d-block', 'w-100'); 
                item.appendChild(img);
                carouselInner.appendChild(item);
            });
        })
        .catch(error => console.error('Error fetching images:', error));
</script>

</body>
</html>
